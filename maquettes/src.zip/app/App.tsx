import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Users, CalendarRange, MessageCircle, BookOpen } from 'lucide-react';

// Components
import { Header } from './components/Header';
import { ModeCard } from './components/ModeCard';
import { FriendsLobby } from './components/FriendsLobby';
import { EventLobby } from './components/EventLobby';
import { ChatLobby } from './components/ChatLobby';
import { FriendsGameScreen } from './components/FriendsGameScreen';
import { EventGameScreen } from './components/EventGameScreen';
import { ChatGameScreen } from './components/ChatGameScreen';
import { ResultsScreen } from './components/ResultsScreen';
import { StyleGuide } from './components/StyleGuide';

type Screen =
  | 'home'
  | 'friends-lobby'
  | 'friends-game'
  | 'event-lobby'
  | 'event-game'
  | 'chat-lobby'
  | 'chat-game'
  | 'results'
  | 'style-guide';

type Mode = 'friends' | 'event' | 'chat';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [currentMode, setCurrentMode] = useState<Mode>('friends');
  const [isPaused, setIsPaused] = useState(false);

  // Game state
  const [score, setScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [streak, setStreak] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);

  // Mock data for friends mode
  const mockFriends = [
    { id: '1', name: 'Marie L.', avatar: '🎵', status: 'online' as const },
    { id: '2', name: 'Thomas B.', avatar: '🎸', status: 'playing' as const },
    { id: '3', name: 'Sophie M.', avatar: '🎹', status: 'online' as const },
    { id: '4', name: 'Lucas D.', avatar: '🎤', status: 'offline' as const },
    { id: '5', name: 'Emma R.', avatar: '🎧', status: 'online' as const },
  ];

  const mockPlayers = [
    { id: '1', name: 'Vous', avatar: '🎮', score: score },
    { id: '2', name: 'Marie L.', avatar: '🎵', score: 120 },
    { id: '3', name: 'Sophie M.', avatar: '🎹', score: 140 },
  ];

  // Mock data for event mode
  const mockParticipants = [
    { id: '1', name: 'Vous', avatar: '🎮', score: score, isHost: true },
    { id: '2', name: 'Joueur 1', avatar: '🎵', score: 120, hasAnswered: true },
    { id: '3', name: 'Joueur 2', avatar: '🎸', score: 140, hasAnswered: false },
    { id: '4', name: 'Joueur 3', avatar: '🎹', score: 100, hasAnswered: true },
    { id: '5', name: 'Joueur 4', avatar: '🎤', score: 130, hasAnswered: true },
    { id: '6', name: 'Joueur 5', avatar: '🎧', score: 110, hasAnswered: false },
  ];

  // Mock data for chat mode
  const [chatMessages, setChatMessages] = useState([
    { id: '1', user: 'StreamerPro', message: 'Salut tout le monde ! 🎵', timestamp: new Date(), isAnswer: false },
    { id: '2', user: 'MusicFan42', message: 'Hey !', timestamp: new Date(), isAnswer: false },
    { id: '3', user: 'Player123', message: 'Prêt pour jouer', timestamp: new Date(), isAnswer: false },
  ]);

  // Handlers
  const handleModeSelect = (mode: Mode) => {
    setCurrentMode(mode);
    if (mode === 'friends') {
      setCurrentScreen('friends-lobby');
    } else if (mode === 'event') {
      setCurrentScreen('event-lobby');
    } else {
      setCurrentScreen('chat-lobby');
    }
    resetGameState();
  };

  const handleStartFriendsGame = () => {
    setCurrentScreen('friends-game');
  };

  const handleStartEventGame = () => {
    setCurrentScreen('event-game');
  };

  const handleStartChatGame = () => {
    setCurrentScreen('chat-game');
  };

  const handleAnswer = (answer: string) => {
    console.log('Answer submitted:', answer);
    
    // Simulate answer checking (random for demo)
    const isCorrect = Math.random() > 0.3;
    
    if (isCorrect) {
      setScore((prev) => prev + 100);
      setCorrectAnswers((prev) => prev + 1);
      setStreak((prev) => {
        const newStreak = prev + 1;
        setBestStreak((best) => Math.max(best, newStreak));
        return newStreak;
      });
    } else {
      setStreak(0);
    }

    // Move to next question or results
    if (questionNumber < 10) {
      setQuestionNumber((prev) => prev + 1);
    } else {
      setCurrentScreen('results');
    }
  };

  const handleSendChatMessage = (message: string) => {
    const newMessage = {
      id: Date.now().toString(),
      user: 'Vous',
      message,
      timestamp: new Date(),
      isAnswer: true,
    };
    setChatMessages((prev) => [...prev, newMessage]);
    
    // Simulate game logic
    setTimeout(() => {
      handleAnswer(message);
    }, 500);
  };

  const handlePlayAgain = () => {
    resetGameState();
    if (currentMode === 'friends') {
      setCurrentScreen('friends-lobby');
    } else if (currentMode === 'event') {
      setCurrentScreen('event-lobby');
    } else {
      setCurrentScreen('chat-lobby');
    }
  };

  const handleBackToHome = () => {
    resetGameState();
    setCurrentScreen('home');
  };

  const resetGameState = () => {
    setScore(0);
    setQuestionNumber(1);
    setStreak(0);
    setCorrectAnswers(0);
    setBestStreak(0);
    setIsPaused(false);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      {currentScreen !== 'style-guide' && (
        <Header
          showBack={currentScreen !== 'home'}
          onBack={() => {
            if (currentScreen.includes('lobby') || currentScreen.includes('game') || currentScreen === 'results') {
              setCurrentScreen('home');
            }
          }}
          currentTrack={
            ['friends-game', 'event-game', 'chat-game'].includes(currentScreen)
              ? 'Now Playing: Track #' + questionNumber
              : undefined
          }
        />
      )}

      {/* Main content */}
      <AnimatePresence mode="wait">
        {currentScreen === 'home' && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pt-24 pb-12 px-4"
          >
            <div className="max-w-7xl mx-auto">
              {/* Hero section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-16"
              >
                <div className="inline-block mb-4">
                  <span className="text-xs uppercase tracking-widest text-white/40">ORIENTATION</span>
                </div>
                <h1 className="text-5xl md:text-6xl mb-6 text-white">
                  Comment tu veux jouer ?
                </h1>
                <p className="text-lg text-white/50 max-w-xl mx-auto">
                  Choisis un mode, je m'occupe du reste.
                </p>

                {/* Style guide button */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setCurrentScreen('style-guide')}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 text-sm transition-colors mt-8"
                >
                  <BookOpen className="w-4 h-4" />
                  Voir le guide de style
                </motion.button>
              </motion.div>

              {/* Mode selection cards */}
              <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
                <ModeCard
                  icon={Users}
                  title="Jouer avec des amis"
                  description="Invite, lance une partie, joue entre potes."
                  accentColor="blue"
                  onClick={() => handleModeSelect('friends')}
                  badge="Social"
                />
                <ModeCard
                  icon={CalendarRange}
                  title="Jouer en événement"
                  description="Un écran, tout un événement, tout le monde suit."
                  accentColor="purple"
                  onClick={() => handleModeSelect('event')}
                  badge="Collectif"
                />
                <ModeCard
                  icon={MessageCircle}
                  title="Jouer avec le chat"
                  description="Le chat joue avec toi, au rythme du jeu."
                  accentColor="pink"
                  onClick={() => handleModeSelect('chat')}
                  badge="Diffusion"
                />
              </div>
            </div>
          </motion.div>
        )}

        {currentScreen === 'friends-lobby' && (
          <motion.div
            key="friends-lobby"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <FriendsLobby 
              friends={mockFriends} 
              onStartGame={handleStartFriendsGame}
            />
          </motion.div>
        )}

        {currentScreen === 'friends-game' && (
          <motion.div
            key="friends-game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <FriendsGameScreen
              onAnswer={handleAnswer}
              questionNumber={questionNumber}
              totalQuestions={10}
              score={score}
              streak={streak}
              players={mockPlayers}
            />
          </motion.div>
        )}

        {currentScreen === 'event-lobby' && (
          <motion.div
            key="event-lobby"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <EventLobby
              isHost={true}
              onStartGame={handleStartEventGame}
              participants={mockParticipants}
            />
          </motion.div>
        )}

        {currentScreen === 'event-game' && (
          <motion.div
            key="event-game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <EventGameScreen
              isHost={true}
              onAnswer={handleAnswer}
              onPauseGame={() => setIsPaused(true)}
              onResumeGame={() => setIsPaused(false)}
              questionNumber={questionNumber}
              totalQuestions={10}
              score={score}
              streak={streak}
              participants={mockParticipants}
            />
          </motion.div>
        )}

        {currentScreen === 'chat-lobby' && (
          <motion.div
            key="chat-lobby"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <ChatLobby 
              onStartGame={handleStartChatGame}
            />
          </motion.div>
        )}

        {currentScreen === 'chat-game' && (
          <motion.div
            key="chat-game"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <ChatGameScreen
              messages={chatMessages}
              onSendMessage={handleSendChatMessage}
              questionNumber={questionNumber}
              totalQuestions={10}
              score={score}
              streak={streak}
            />
          </motion.div>
        )}

        {currentScreen === 'results' && (
          <motion.div
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <ResultsScreen
              mode={currentMode}
              score={score}
              totalQuestions={10}
              correctAnswers={correctAnswers}
              bestStreak={bestStreak}
              onPlayAgain={handlePlayAgain}
              onBackToHome={handleBackToHome}
            />
          </motion.div>
        )}

        {currentScreen === 'style-guide' && (
          <motion.div
            key="style-guide"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <StyleGuide />
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCurrentScreen('home')}
                className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-2xl"
              >
                Retour à l'accueil
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
