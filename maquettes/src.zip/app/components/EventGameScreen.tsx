import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Trophy, Zap, Clock, Users, Crown, Check, X, Pause, Play } from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  avatar: string;
  score: number;
  hasAnswered?: boolean;
  isCorrect?: boolean;
}

interface EventGameScreenProps {
  isHost: boolean;
  onAnswer: (answer: string) => void;
  onPauseGame?: () => void;
  onResumeGame?: () => void;
  questionNumber: number;
  totalQuestions: number;
  score: number;
  streak: number;
  participants: Participant[];
}

export function EventGameScreen({
  isHost,
  onAnswer,
  onPauseGame,
  onResumeGame,
  questionNumber,
  totalQuestions,
  score,
  streak,
  participants,
}: EventGameScreenProps) {
  const [timeLeft, setTimeLeft] = useState(20);
  const [isPaused, setIsPaused] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  // Mock question data
  const question = {
    id: questionNumber,
    artist: 'Arctic Monkeys',
    title: 'Do I Wanna Know?',
    album: 'AM',
    year: 2013,
    audioWave: [0.3, 0.6, 0.9, 0.7, 0.8, 0.5, 0.6, 0.4, 0.7, 0.9, 0.5, 0.8, 0.6, 0.4, 0.7],
  };

  const answers = [
    'Arctic Monkeys - Do I Wanna Know?',
    'The Strokes - Reptilia',
    'Kings of Leon - Sex on Fire',
    'Franz Ferdinand - Take Me Out',
  ];

  useEffect(() => {
    if (timeLeft > 0 && !showResult && !isPaused) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult) {
      handleSubmit(null);
    }
  }, [timeLeft, showResult, isPaused]);

  const handleSubmit = (answer: string | null) => {
    setShowResult(true);
    const correct = answer === answers[0];
    setIsCorrect(correct);
    
    setTimeout(() => {
      onAnswer(answer || '');
      setTimeLeft(20);
      setShowResult(false);
      setSelectedAnswer(null);
    }, 3000);
  };

  const handleAnswerClick = (answer: string) => {
    if (!showResult && !selectedAnswer && !isPaused) {
      setSelectedAnswer(answer);
      handleSubmit(answer);
    }
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
    if (!isPaused) {
      onPauseGame?.();
    } else {
      onResumeGame?.();
    }
  };

  const answeredCount = participants.filter((p) => p.hasAnswered).length;

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Progress bar */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-white/60">
              Question {questionNumber} / {totalQuestions}
            </span>
            <div className="flex items-center gap-4">
              <span className="text-sm text-white/60">
                {answeredCount}/{participants.length} ont répondu
              </span>
              <span className="text-sm text-purple-400">
                {Math.round((questionNumber / totalQuestions) * 100)}%
              </span>
            </div>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              className="h-full bg-gradient-to-r from-purple-500 to-violet-500"
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main game area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Host controls */}
            {isHost && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-between p-4 rounded-xl bg-purple-500/10 border border-purple-500/20"
              >
                <div className="flex items-center gap-2">
                  <Crown className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-white/80">Contrôles hôte</span>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handlePause}
                  className="px-4 py-2 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/30 text-purple-400 transition-colors flex items-center gap-2"
                >
                  {isPaused ? (
                    <>
                      <Play className="w-4 h-4" />
                      Reprendre
                    </>
                  ) : (
                    <>
                      <Pause className="w-4 h-4" />
                      Pause
                    </>
                  )}
                </motion.button>
              </motion.div>
            )}

            {/* Pause overlay */}
            <AnimatePresence>
              {isPaused && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="p-8 rounded-2xl bg-purple-500/20 border-2 border-purple-500/50 text-center"
                >
                  <Pause className="w-12 h-12 mx-auto mb-4 text-purple-400" />
                  <h3 className="text-2xl text-purple-300 mb-2">Partie en pause</h3>
                  <p className="text-white/60">L'hôte a mis le jeu en pause</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Question card */}
            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 rounded-2xl bg-gradient-to-br from-purple-500/10 to-violet-500/10 border border-purple-500/20 backdrop-blur-sm"
            >
              {/* Timer and streak */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center border-4 ${
                    isPaused
                      ? 'border-white/20'
                      : timeLeft > 5
                      ? 'border-purple-400'
                      : 'border-red-400 animate-pulse'
                  } bg-black/50`}>
                    {isPaused ? (
                      <Pause className="w-6 h-6 text-white/40" />
                    ) : (
                      <span className={`text-2xl ${timeLeft > 5 ? 'text-purple-400' : 'text-red-400'}`}>
                        {timeLeft}
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Temps restant</div>
                    <div className="text-white">20 secondes</div>
                  </div>
                </div>

                {streak > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/20 border border-purple-500/30"
                  >
                    <Zap className="w-4 h-4 text-purple-400" />
                    <span className="text-purple-400">Série: {streak}</span>
                  </motion.div>
                )}
              </div>

              {/* Audio visualization */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                    <Music className={`w-6 h-6 text-purple-400 ${!isPaused && 'animate-pulse'}`} />
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Morceau en cours</div>
                    <div className="text-white">
                      {isPaused ? 'En pause...' : 'Écoutez attentivement...'}
                    </div>
                  </div>
                </div>

                {/* Waveform visualization */}
                <div className="flex items-end justify-center gap-1 h-32 bg-black/30 rounded-xl p-4">
                  {question.audioWave.map((height, i) => (
                    <motion.div
                      key={i}
                      initial={{ scaleY: 0 }}
                      animate={{ scaleY: isPaused ? 0.3 : 1 }}
                      transition={{
                        delay: i * 0.05,
                        repeat: isPaused ? 0 : Infinity,
                        repeatDelay: 1,
                      }}
                      className="flex-1 bg-gradient-to-t from-purple-500 to-violet-400 rounded-full"
                      style={{ height: `${height * 100}%` }}
                    />
                  ))}
                </div>
              </div>

              {/* Result feedback */}
              <AnimatePresence>
                {showResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`p-4 rounded-xl border-2 ${
                      isCorrect
                        ? 'bg-green-500/20 border-green-500/50'
                        : 'bg-red-500/20 border-red-500/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {isCorrect ? (
                        <Check className="w-6 h-6 text-green-400" />
                      ) : (
                        <X className="w-6 h-6 text-red-400" />
                      )}
                      <div>
                        <div className={`${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                          {isCorrect ? 'Bravo !' : 'Dommage !'}
                        </div>
                        <div className="text-sm text-white/80">
                          {question.artist} - {question.title}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Answer options */}
            <div className="grid grid-cols-2 gap-4">
              {answers.map((answer, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: showResult || isPaused ? 1 : 1.02 }}
                  whileTap={{ scale: showResult || isPaused ? 1 : 0.98 }}
                  onClick={() => handleAnswerClick(answer)}
                  disabled={showResult || selectedAnswer !== null || isPaused}
                  className={`p-6 rounded-xl text-left transition-all ${
                    showResult && answer === answers[0]
                      ? 'bg-green-500/20 border-2 border-green-500/50'
                      : showResult && answer === selectedAnswer
                      ? 'bg-red-500/20 border-2 border-red-500/50'
                      : selectedAnswer === answer
                      ? 'bg-purple-500/20 border-2 border-purple-500/50'
                      : isPaused
                      ? 'bg-white/5 border border-white/10 opacity-50'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                  } disabled:cursor-not-allowed`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      showResult && answer === answers[0]
                        ? 'bg-green-500/30'
                        : showResult && answer === selectedAnswer
                        ? 'bg-red-500/30'
                        : 'bg-purple-500/20'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-white">{answer}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Sidebar - Stats and leaderboard */}
          <div className="space-y-6">
            {/* Your score */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="p-6 rounded-2xl bg-gradient-to-br from-purple-500/10 to-violet-500/10 border border-purple-500/20"
            >
              <div className="flex items-center gap-3 mb-4">
                <Trophy className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg">Votre score</h3>
              </div>
              <div className="text-4xl text-purple-400 mb-2">{score}</div>
              <div className="text-sm text-white/60">Points</div>
            </motion.div>

            {/* Live leaderboard */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10"
            >
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg">Classement live</h3>
              </div>

              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {participants
                  .sort((a, b) => b.score - a.score)
                  .map((participant, index) => (
                    <motion.div
                      key={participant.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className={`p-3 rounded-xl ${
                        index === 0
                          ? 'bg-purple-500/20 border border-purple-500/30'
                          : 'bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${
                            index === 0
                              ? 'bg-purple-500/30 text-purple-400'
                              : 'bg-white/10 text-white/60'
                          }`}
                        >
                          {index + 1}
                        </div>
                        <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-sm">
                          {participant.avatar}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-1">
                            <span className="text-white text-sm">{participant.name}</span>
                            {participant.isHost && (
                              <Crown className="w-3 h-3 text-purple-400" />
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-purple-400 text-sm">{participant.score}</div>
                          {participant.hasAnswered && (
                            <div className="text-xs text-white/40">Répondu</div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
