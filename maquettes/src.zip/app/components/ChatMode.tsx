import { motion } from 'motion/react';
import { MessageCircle, Send, Music } from 'lucide-react';
import { useState } from 'react';

interface ChatMessage {
  id: string;
  user: string;
  message: string;
  isAnswer?: boolean;
  timestamp: Date;
}

interface ChatModeProps {
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
  isGameActive: boolean;
  answerDelay?: number; // seconds before can answer
}

export function ChatMode({ messages, onSendMessage, isGameActive, answerDelay = 3 }: ChatModeProps) {
  const [message, setMessage] = useState('');
  const [canAnswer, setCanAnswer] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message);
      setMessage('');
    }
  };

  // Simulate answer delay
  useState(() => {
    if (isGameActive) {
      setTimeout(() => setCanAnswer(true), answerDelay * 1000);
    }
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h2 className="text-3xl bg-gradient-to-r from-pink-300 to-rose-300 bg-clip-text text-transparent mb-2">
            Mode Chat
          </h2>
          <p className="text-white/60">Devinez les titres avec votre communauté</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Game zone */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2"
          >
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8 mb-6">
              {isGameActive ? (
                <div>
                  {/* Audio visualization */}
                  <div className="mb-8 p-12 rounded-2xl bg-gradient-to-br from-pink-500/20 to-rose-500/20 border-2 border-pink-500/30 relative">
                    <div className="flex items-center justify-center gap-2 h-32">
                      {[...Array(12)].map((_, i) => (
                        <motion.div
                          key={i}
                          animate={{
                            height: ['20%', '100%', '40%', '80%', '20%'],
                          }}
                          transition={{
                            duration: 1.5,
                            repeat: Infinity,
                            delay: i * 0.1,
                            ease: 'easeInOut',
                          }}
                          className="w-3 bg-gradient-to-t from-pink-500 to-rose-500 rounded-full"
                        />
                      ))}
                    </div>
                    <motion.div
                      animate={{ rotate: [0, 10, -10, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute top-6 left-6"
                    >
                      <Music className="w-8 h-8 text-pink-400" />
                    </motion.div>
                  </div>

                  {/* Answer delay indicator */}
                  {!canAnswer && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 rounded-xl bg-orange-500/20 border border-orange-400/30 text-center"
                    >
                      <p className="text-orange-300">
                        ⏱️ Répondez après {answerDelay} secondes de lecture
                      </p>
                    </motion.div>
                  )}
                </div>
              ) : (
                /* Waiting state */
                <div className="text-center py-12">
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center"
                  >
                    <MessageCircle className="w-12 h-12 text-white" />
                  </motion.div>
                  <h3 className="text-2xl text-white mb-2">Prêt à jouer</h3>
                  <p className="text-white/60">La prochaine track va bientôt commencer</p>
                </div>
              )}
            </div>

            {/* OBS Integration Info */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="p-4 rounded-xl bg-blue-500/10 border border-blue-400/30"
            >
              <p className="text-blue-300 text-sm">
                💡 <strong>Astuce stream:</strong> Cette interface est optimisée pour OBS. 
                Utilisez le mode "Capture de fenêtre" pour intégrer le jeu à votre stream.
              </p>
            </motion.div>
          </motion.div>

          {/* Chat zone */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-white/5 border border-white/10 rounded-2xl overflow-hidden h-[600px] flex flex-col">
              {/* Chat header */}
              <div className="p-4 border-b border-white/10 bg-pink-500/10">
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-pink-400" />
                  <h3 className="text-white">Chat en direct</h3>
                  <div className="ml-auto w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {messages.map((msg, index) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`p-3 rounded-lg ${
                      msg.isAnswer
                        ? 'bg-pink-500/20 border border-pink-400/30'
                        : 'bg-white/5'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-400 to-rose-600 flex items-center justify-center text-xs flex-shrink-0">
                        {msg.user[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-2 mb-1">
                          <span className="text-sm text-white/90 font-medium">{msg.user}</span>
                          <span className="text-xs text-white/40">
                            {msg.timestamp.toLocaleTimeString('fr-FR', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                        <p className="text-sm text-white/70 break-words">{msg.message}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Input */}
              <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder={
                      canAnswer ? 'Votre réponse...' : 'Attendez le délai...'
                    }
                    disabled={!canAnswer && isGameActive}
                    className="flex-1 px-4 py-2 bg-white/5 border border-white/10 focus:border-pink-400/50 rounded-lg text-white text-sm placeholder-white/40 outline-none transition-colors disabled:opacity-50"
                  />
                  <motion.button
                    type="submit"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    disabled={!message.trim() || (!canAnswer && isGameActive)}
                    className="p-2 rounded-lg bg-gradient-to-r from-pink-500 to-rose-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                  </motion.button>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
