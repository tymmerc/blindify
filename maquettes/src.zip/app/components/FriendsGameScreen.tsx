import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Trophy, Zap, Clock, Users, Check, X } from 'lucide-react';

interface Player {
  id: string;
  name: string;
  avatar: string;
  score: number;
}

interface FriendsGameScreenProps {
  onAnswer: (answer: string) => void;
  questionNumber: number;
  totalQuestions: number;
  score: number;
  streak: number;
  players: Player[];
}

export function FriendsGameScreen({
  onAnswer,
  questionNumber,
  totalQuestions,
  score,
  streak,
  players,
}: FriendsGameScreenProps) {
  const [timeLeft, setTimeLeft] = useState(15);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  // Mock question data
  const question = {
    id: questionNumber,
    artist: 'Daft Punk',
    title: 'Get Lucky',
    album: 'Random Access Memories',
    year: 2013,
    audioWave: [0.2, 0.5, 0.8, 0.6, 0.9, 0.4, 0.7, 0.5, 0.8, 0.3, 0.6, 0.9, 0.5, 0.7, 0.4],
  };

  const answers = [
    'Daft Punk - Get Lucky',
    'Pharrell Williams - Happy',
    'Mark Ronson - Uptown Funk',
    'Bruno Mars - Treasure',
  ];

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult) {
      handleSubmit(null);
    }
  }, [timeLeft, showResult]);

  const handleSubmit = (answer: string | null) => {
    setShowResult(true);
    const correct = answer === answers[0];
    setIsCorrect(correct);
    
    setTimeout(() => {
      onAnswer(answer || '');
      setTimeLeft(15);
      setShowResult(false);
      setSelectedAnswer(null);
    }, 2000);
  };

  const handleAnswerClick = (answer: string) => {
    if (!showResult && !selectedAnswer) {
      setSelectedAnswer(answer);
      handleSubmit(answer);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Progress bar */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-white/60">
              Question {questionNumber} / {totalQuestions}
            </span>
            <span className="text-sm text-pink-400">{Math.round((questionNumber / totalQuestions) * 100)}%</span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              className="h-full bg-gradient-to-r from-pink-500 to-rose-500"
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main game area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Question card */}
            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 rounded-2xl bg-gradient-to-br from-pink-500/10 to-rose-500/10 border border-pink-500/20 backdrop-blur-sm"
            >
              {/* Timer and streak */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center border-4 ${
                    timeLeft > 5 ? 'border-pink-400' : 'border-red-400 animate-pulse'
                  } bg-black/50`}>
                    <span className={`text-2xl ${timeLeft > 5 ? 'text-pink-400' : 'text-red-400'}`}>
                      {timeLeft}
                    </span>
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Temps restant</div>
                    <div className="text-white">15 secondes</div>
                  </div>
                </div>

                {streak > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-pink-500/20 border border-pink-500/30"
                  >
                    <Zap className="w-4 h-4 text-pink-400" />
                    <span className="text-pink-400">Série: {streak}</span>
                  </motion.div>
                )}
              </div>

              {/* Audio visualization */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-pink-500/20 flex items-center justify-center">
                    <Music className="w-6 h-6 text-pink-400 animate-pulse" />
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Morceau en cours</div>
                    <div className="text-white">Écoutez attentivement...</div>
                  </div>
                </div>

                {/* Waveform visualization */}
                <div className="flex items-end justify-center gap-1 h-32 bg-black/30 rounded-xl p-4">
                  {question.audioWave.map((height, i) => (
                    <motion.div
                      key={i}
                      initial={{ scaleY: 0 }}
                      animate={{ scaleY: 1 }}
                      transition={{ delay: i * 0.05, repeat: Infinity, repeatDelay: 1 }}
                      className="flex-1 bg-gradient-to-t from-pink-500 to-rose-400 rounded-full"
                      style={{ height: `${height * 100}%` }}
                    />
                  ))}
                </div>
              </div>

              {/* Result feedback */}
              <AnimatePresence>
                {showResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className={`p-4 rounded-xl border-2 ${
                      isCorrect
                        ? 'bg-green-500/20 border-green-500/50'
                        : 'bg-red-500/20 border-red-500/50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {isCorrect ? (
                        <Check className="w-6 h-6 text-green-400" />
                      ) : (
                        <X className="w-6 h-6 text-red-400" />
                      )}
                      <div>
                        <div className={`${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                          {isCorrect ? 'Bravo !' : 'Dommage !'}
                        </div>
                        <div className="text-sm text-white/80">
                          {question.artist} - {question.title}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Answer options */}
            <div className="grid grid-cols-2 gap-4">
              {answers.map((answer, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: showResult ? 1 : 1.02 }}
                  whileTap={{ scale: showResult ? 1 : 0.98 }}
                  onClick={() => handleAnswerClick(answer)}
                  disabled={showResult || selectedAnswer !== null}
                  className={`p-6 rounded-xl text-left transition-all ${
                    showResult && answer === answers[0]
                      ? 'bg-green-500/20 border-2 border-green-500/50'
                      : showResult && answer === selectedAnswer
                      ? 'bg-red-500/20 border-2 border-red-500/50'
                      : selectedAnswer === answer
                      ? 'bg-pink-500/20 border-2 border-pink-500/50'
                      : 'bg-white/5 border border-white/10 hover:bg-white/10'
                  } disabled:cursor-not-allowed`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                      showResult && answer === answers[0]
                        ? 'bg-green-500/30'
                        : showResult && answer === selectedAnswer
                        ? 'bg-red-500/30'
                        : 'bg-pink-500/20'
                    }`}>
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span className="text-white">{answer}</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Sidebar - Stats and leaderboard */}
          <div className="space-y-6">
            {/* Your score */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="p-6 rounded-2xl bg-gradient-to-br from-pink-500/10 to-rose-500/10 border border-pink-500/20"
            >
              <div className="flex items-center gap-3 mb-4">
                <Trophy className="w-5 h-5 text-pink-400" />
                <h3 className="text-lg">Votre score</h3>
              </div>
              <div className="text-4xl text-pink-400 mb-2">{score}</div>
              <div className="text-sm text-white/60">Points</div>
            </motion.div>

            {/* Live leaderboard */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10"
            >
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-5 h-5 text-pink-400" />
                <h3 className="text-lg">Classement</h3>
              </div>

              <div className="space-y-3">
                {players
                  .sort((a, b) => b.score - a.score)
                  .map((player, index) => (
                    <motion.div
                      key={player.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className={`p-3 rounded-xl ${
                        index === 0
                          ? 'bg-pink-500/20 border border-pink-500/30'
                          : 'bg-white/5'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            index === 0
                              ? 'bg-pink-500/30 text-pink-400'
                              : 'bg-white/10 text-white/60'
                          }`}
                        >
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <div className="text-white text-sm">{player.name}</div>
                        </div>
                        <div className="text-pink-400">{player.score}</div>
                      </div>
                    </motion.div>
                  ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
