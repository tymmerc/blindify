import { motion } from 'motion/react';
import { Circle, Play, UserPlus } from 'lucide-react';

interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'offline' | 'playing';
}

interface FriendsListProps {
  friends: Friend[];
  onInvite: (friendId: string) => void;
}

const statusConfig = {
  online: {
    color: 'bg-green-400',
    text: 'En ligne',
    textColor: 'text-green-400',
  },
  offline: {
    color: 'bg-gray-500',
    text: 'Hors ligne',
    textColor: 'text-gray-500',
  },
  playing: {
    color: 'bg-purple-400',
    text: 'En partie',
    textColor: 'text-purple-400',
  },
};

export function FriendsList({ friends, onInvite }: FriendsListProps) {
  return (
    <div className="space-y-4">
      {/* Add friend button */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className="w-full flex items-center justify-center gap-3 p-4 rounded-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-2 border-dashed border-blue-400/30 hover:border-blue-400/60 transition-colors"
      >
        <UserPlus className="w-5 h-5 text-blue-400" />
        <span className="text-white/80">Inviter un ami</span>
      </motion.button>

      {/* Friends list */}
      <div className="space-y-3">
        {friends.map((friend, index) => (
          <motion.div
            key={friend.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="group relative bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-4 transition-all duration-300"
          >
            <div className="flex items-center gap-4">
              {/* Avatar with status indicator */}
              <div className="relative">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center">
                  <span className="text-lg">{friend.avatar}</span>
                </div>
                <motion.div
                  animate={{
                    scale: friend.status === 'online' ? [1, 1.2, 1] : 1,
                  }}
                  transition={{
                    duration: 2,
                    repeat: friend.status === 'online' ? Infinity : 0,
                  }}
                  className={`absolute bottom-0 right-0 w-4 h-4 ${statusConfig[friend.status].color} border-2 border-gray-900 rounded-full`}
                />
              </div>

              {/* Friend info */}
              <div className="flex-1">
                <h4 className="text-white mb-1">{friend.name}</h4>
                <div className="flex items-center gap-2">
                  <Circle className={`w-2 h-2 ${statusConfig[friend.status].textColor} fill-current`} />
                  <span className={`text-sm ${statusConfig[friend.status].textColor}`}>
                    {statusConfig[friend.status].text}
                  </span>
                </div>
              </div>

              {/* Invite button */}
              {friend.status === 'online' && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onInvite(friend.id)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 text-white opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Play className="w-4 h-4" />
                  <span className="text-sm">Inviter</span>
                </motion.button>
              )}

              {friend.status === 'playing' && (
                <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/30">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
                  <span className="text-xs text-purple-300">En jeu</span>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
