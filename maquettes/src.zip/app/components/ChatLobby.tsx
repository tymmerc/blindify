import { useState } from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Settings, Play, Music2, Clock, Trophy, Twitch, Youtube, Hash, Users } from 'lucide-react';

interface ChatLobbyProps {
  onStartGame: () => void;
}

export function ChatLobby({ onStartGame }: ChatLobbyProps) {
  const [platform, setPlatform] = useState<'twitch' | 'youtube' | 'discord'>('twitch');
  const [channelName, setChannelName] = useState('');
  const [selectedPlaylist, setSelectedPlaylist] = useState('top-hits');
  const [rounds, setRounds] = useState(10);
  const [difficulty, setDifficulty] = useState('medium');
  const [isConnected, setIsConnected] = useState(false);
  const [viewerCount, setViewerCount] = useState(247);

  const playlists = [
    { id: 'top-hits', name: 'Top Hits 2024', count: 150 },
    { id: 'requests', name: 'Demandes chat', count: 85 },
    { id: 'variety', name: 'Mix varié', count: 300 },
    { id: 'throwback', name: 'Oldies', count: 220 },
  ];

  const handleConnect = () => {
    // Simulate connection
    setIsConnected(true);
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-4">
            <div className="w-2 h-2 rounded-full bg-cyan-500" />
            <span className="text-xs uppercase tracking-wider text-cyan-400">Mode Diffusion</span>
          </div>
          <h1 className="text-5xl mb-3 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            Jouer avec le chat
          </h1>
          <p className="text-white/60">
            Connectez votre chat et jouez en direct avec votre communauté
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column - Settings */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Platform connection */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <MessageCircle className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Plateforme de streaming</h3>
              </div>

              <div className="space-y-4">
                {/* Platform selection */}
                <div>
                  <label className="block text-sm text-white/60 mb-2">
                    Choisir une plateforme
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setPlatform('twitch')}
                      className={`p-4 rounded-xl transition-all ${
                        platform === 'twitch'
                          ? 'bg-cyan-500/20 border-2 border-cyan-500/50'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Twitch className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
                      <div className="text-sm">Twitch</div>
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setPlatform('youtube')}
                      className={`p-4 rounded-xl transition-all ${
                        platform === 'youtube'
                          ? 'bg-cyan-500/20 border-2 border-cyan-500/50'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Youtube className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
                      <div className="text-sm">YouTube</div>
                    </motion.button>

                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setPlatform('discord')}
                      className={`p-4 rounded-xl transition-all ${
                        platform === 'discord'
                          ? 'bg-cyan-500/20 border-2 border-cyan-500/50'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <Hash className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
                      <div className="text-sm">Discord</div>
                    </motion.button>
                  </div>
                </div>

                {/* Channel name */}
                {!isConnected ? (
                  <div>
                    <label className="block text-sm text-white/60 mb-2">
                      {platform === 'twitch' && 'Nom de la chaîne Twitch'}
                      {platform === 'youtube' && 'ID de diffusion YouTube'}
                      {platform === 'discord' && 'ID du salon Discord'}
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={channelName}
                        onChange={(e) => setChannelName(e.target.value)}
                        className="flex-1 px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-cyan-500/50 transition-colors"
                        placeholder={
                          platform === 'twitch'
                            ? 'votre_chaine'
                            : platform === 'youtube'
                            ? 'ID de diffusion'
                            : 'ID du salon'
                        }
                      />
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={handleConnect}
                        disabled={!channelName}
                        className="px-6 py-3 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/30 text-cyan-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Connecter
                      </motion.button>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                          {platform === 'twitch' && <Twitch className="w-5 h-5 text-cyan-400" />}
                          {platform === 'youtube' && <Youtube className="w-5 h-5 text-cyan-400" />}
                          {platform === 'discord' && <Hash className="w-5 h-5 text-cyan-400" />}
                        </div>
                        <div>
                          <div className="text-white">Connecté</div>
                          <div className="text-sm text-white/60">{channelName || 'votre_chaine'}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        <span className="text-sm text-white/60">En direct</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Playlist selection */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <Music2 className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Playlist</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {playlists.map((playlist) => (
                  <motion.button
                    key={playlist.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedPlaylist(playlist.id)}
                    className={`p-4 rounded-xl text-left transition-all ${
                      selectedPlaylist === playlist.id
                        ? 'bg-cyan-500/20 border-2 border-cyan-500/50'
                        : 'bg-white/5 border border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div className="text-white mb-1">{playlist.name}</div>
                    <div className="text-sm text-white/40">{playlist.count} morceaux</div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Game settings */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-6">
                <Settings className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Paramètres de jeu</h3>
              </div>

              <div className="space-y-6">
                {/* Rounds */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-white/60" />
                      <span className="text-white/80">Nombre de rounds</span>
                    </div>
                    <span className="text-cyan-400">{rounds}</span>
                  </div>
                  <div className="flex gap-2">
                    {[5, 10, 15, 20].map((value) => (
                      <motion.button
                        key={value}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setRounds(value)}
                        className={`flex-1 py-2 rounded-lg transition-all ${
                          rounds === value
                            ? 'bg-cyan-500/30 border border-cyan-500/50'
                            : 'bg-white/5 border border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {value}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Difficulty */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Trophy className="w-4 h-4 text-white/60" />
                    <span className="text-white/80">Difficulté</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['easy', 'medium', 'hard'].map((level) => (
                      <motion.button
                        key={level}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setDifficulty(level)}
                        className={`py-2 rounded-lg capitalize transition-all ${
                          difficulty === level
                            ? 'bg-cyan-500/30 border border-cyan-500/50'
                            : 'bg-white/5 border border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {level === 'easy' && 'Facile'}
                        {level === 'medium' && 'Moyen'}
                        {level === 'hard' && 'Difficile'}
                      </motion.button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Chat rules info */}
            <div className="p-6 rounded-2xl bg-cyan-500/10 border border-cyan-500/20">
              <h3 className="text-cyan-300 mb-3">Règles du jeu</h3>
              <ul className="space-y-2 text-sm text-white/60">
                <li>• Les spectateurs répondent dans le chat</li>
                <li>• Le premier à donner la bonne réponse gagne</li>
                <li>• Format: !reponse [artiste - titre]</li>
                <li>• Un classement en temps réel est affiché</li>
              </ul>
            </div>
          </motion.div>

          {/* Right column - Stream info & stats */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Stream stats */}
            {isConnected && (
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Users className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-lg">Statistiques du stream</h3>
                </div>

                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                    <div className="text-3xl text-cyan-400 mb-1">{viewerCount}</div>
                    <div className="text-sm text-white/60">Spectateurs en direct</div>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5">
                    <div className="text-2xl text-white mb-1">12</div>
                    <div className="text-sm text-white/60">Joueurs actifs</div>
                  </div>

                  <div className="p-4 rounded-xl bg-white/5">
                    <div className="text-2xl text-white mb-1">156</div>
                    <div className="text-sm text-white/60">Messages chat</div>
                  </div>
                </div>
              </div>
            )}

            {/* Recent chat activity */}
            {isConnected && (
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <h3 className="text-lg mb-4">Activité récente</h3>
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-white/60">MusicLover joined</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                    <span className="text-white/60">ProPlayer joined</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-2 h-2 rounded-full bg-cyan-400" />
                    <span className="text-white/60">Chat is ready!</span>
                  </div>
                </div>
              </div>
            )}

            {/* Start button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onStartGame}
              disabled={!isConnected}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 transition-shadow disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5" />
              Démarrer le blind test
            </motion.button>

            {!isConnected && (
              <p className="text-sm text-white/40 text-center">
                Connectez-vous à une plateforme pour commencer
              </p>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
