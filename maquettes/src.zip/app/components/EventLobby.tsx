import { useState } from 'react';
import { motion } from 'motion/react';
import { CalendarRange, Users, Settings, Play, Music2, Clock, Trophy, Globe, Lock, Crown } from 'lucide-react';

interface Participant {
  id: string;
  name: string;
  avatar: string;
  score?: number;
  isHost?: boolean;
}

interface EventLobbyProps {
  isHost: boolean;
  onStartGame: () => void;
  participants: Participant[];
}

export function EventLobby({ isHost, onStartGame, participants }: EventLobbyProps) {
  const [eventName, setEventName] = useState('Blind Test du Vendredi');
  const [visibility, setVisibility] = useState<'public' | 'private'>('public');
  const [selectedPlaylist, setSelectedPlaylist] = useState('top-hits');
  const [rounds, setRounds] = useState(15);
  const [difficulty, setDifficulty] = useState('medium');

  const playlists = [
    { id: 'top-hits', name: 'Top Hits 2024', count: 150 },
    { id: '90s', name: 'Années 90', count: 200 },
    { id: 'electronic', name: 'Électro', count: 180 },
    { id: 'mixed', name: 'Mix varié', count: 300 },
  ];

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 mb-4">
            <div className="w-2 h-2 rounded-full bg-purple-500" />
            <span className="text-xs uppercase tracking-wider text-purple-400">Mode Collectif</span>
          </div>
          <h1 className="text-5xl mb-3 bg-gradient-to-r from-purple-400 to-violet-400 bg-clip-text text-transparent">
            {isHost ? 'Organiser un événement' : 'Salon événement'}
          </h1>
          <p className="text-white/60">
            {isHost
              ? 'Configurez votre événement et attendez les participants'
              : 'En attente du démarrage par l\'hôte'}
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column - Event settings */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Event info */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <CalendarRange className="w-5 h-5 text-purple-400" />
                <h3 className="text-lg">Informations de l'événement</h3>
              </div>

              <div className="space-y-4">
                {isHost ? (
                  <>
                    <div>
                      <label className="block text-sm text-white/60 mb-2">
                        Nom de l'événement
                      </label>
                      <input
                        type="text"
                        value={eventName}
                        onChange={(e) => setEventName(e.target.value)}
                        className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:border-purple-500/50 transition-colors"
                        placeholder="Ex: Blind Test du Vendredi"
                      />
                    </div>

                    <div>
                      <label className="block text-sm text-white/60 mb-2">Visibilité</label>
                      <div className="grid grid-cols-2 gap-3">
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setVisibility('public')}
                          className={`p-3 rounded-lg transition-all ${
                            visibility === 'public'
                              ? 'bg-purple-500/20 border-2 border-purple-500/50'
                              : 'bg-white/5 border border-white/10 hover:bg-white/10'
                          }`}
                        >
                          <Globe className="w-5 h-5 mx-auto mb-1 text-purple-400" />
                          <div className="text-sm">Public</div>
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => setVisibility('private')}
                          className={`p-3 rounded-lg transition-all ${
                            visibility === 'private'
                              ? 'bg-purple-500/20 border-2 border-purple-500/50'
                              : 'bg-white/5 border border-white/10 hover:bg-white/10'
                          }`}
                        >
                          <Lock className="w-5 h-5 mx-auto mb-1 text-purple-400" />
                          <div className="text-sm">Privé</div>
                        </motion.button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
                    <h4 className="text-xl text-purple-300 mb-2">{eventName}</h4>
                    <div className="flex items-center gap-4 text-sm text-white/60">
                      <div className="flex items-center gap-1">
                        {visibility === 'public' ? (
                          <Globe className="w-4 h-4" />
                        ) : (
                          <Lock className="w-4 h-4" />
                        )}
                        {visibility === 'public' ? 'Public' : 'Privé'}
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-4 h-4" />
                        {participants.length} participants
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Playlist selection */}
            {isHost && (
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="flex items-center gap-3 mb-4">
                  <Music2 className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg">Playlist</h3>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {playlists.map((playlist) => (
                    <motion.button
                      key={playlist.id}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => setSelectedPlaylist(playlist.id)}
                      className={`p-4 rounded-xl text-left transition-all ${
                        selectedPlaylist === playlist.id
                          ? 'bg-purple-500/20 border-2 border-purple-500/50'
                          : 'bg-white/5 border border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <div className="text-white mb-1">{playlist.name}</div>
                      <div className="text-sm text-white/40">{playlist.count} morceaux</div>
                    </motion.button>
                  ))}
                </div>
              </div>
            )}

            {/* Game settings */}
            {isHost && (
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="flex items-center gap-3 mb-6">
                  <Settings className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg">Paramètres de jeu</h3>
                </div>

                <div className="space-y-6">
                  {/* Rounds */}
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-white/60" />
                        <span className="text-white/80">Nombre de rounds</span>
                      </div>
                      <span className="text-purple-400">{rounds}</span>
                    </div>
                    <div className="flex gap-2">
                      {[10, 15, 20, 25].map((value) => (
                        <motion.button
                          key={value}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setRounds(value)}
                          className={`flex-1 py-2 rounded-lg transition-all ${
                            rounds === value
                              ? 'bg-purple-500/30 border border-purple-500/50'
                              : 'bg-white/5 border border-white/10 hover:bg-white/10'
                          }`}
                        >
                          {value}
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* Difficulty */}
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Trophy className="w-4 h-4 text-white/60" />
                      <span className="text-white/80">Difficulté</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {['easy', 'medium', 'hard'].map((level) => (
                        <motion.button
                          key={level}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setDifficulty(level)}
                          className={`py-2 rounded-lg capitalize transition-all ${
                            difficulty === level
                              ? 'bg-purple-500/30 border border-purple-500/50'
                              : 'bg-white/5 border border-white/10 hover:bg-white/10'
                          }`}
                        >
                          {level === 'easy' && 'Facile'}
                          {level === 'medium' && 'Moyen'}
                          {level === 'hard' && 'Difficile'}
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Waiting message for participants */}
            {!isHost && (
              <div className="p-8 rounded-2xl bg-purple-500/10 border border-purple-500/20 backdrop-blur-sm text-center">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <Clock className="w-8 h-8 text-purple-400 animate-pulse" />
                </div>
                <h3 className="text-xl text-purple-300 mb-2">En attente...</h3>
                <p className="text-white/60">
                  L'hôte prépare l'événement. La partie commencera bientôt !
                </p>
              </div>
            )}
          </motion.div>

          {/* Right column - Participants */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Participants list */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg">Participants</h3>
                </div>
                <span className="text-sm text-white/60">{participants.length}/50</span>
              </div>

              <div className="space-y-2 max-h-[600px] overflow-y-auto">
                {participants.map((participant) => (
                  <div
                    key={participant.id}
                    className={`p-3 rounded-xl transition-all ${
                      participant.isHost
                        ? 'bg-purple-500/10 border border-purple-500/20'
                        : 'bg-white/5 border border-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          participant.isHost ? 'bg-purple-500/30' : 'bg-white/10'
                        }`}
                      >
                        {participant.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-white">{participant.name}</span>
                          {participant.isHost && (
                            <Crown className="w-3 h-3 text-purple-400" />
                          )}
                        </div>
                        <span className="text-xs text-white/60">
                          {participant.isHost ? 'Organisateur' : 'Participant'}
                        </span>
                      </div>
                      <div className="w-2 h-2 rounded-full bg-green-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Start button (host only) */}
            {isHost && (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onStartGame}
                disabled={participants.length < 2}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-purple-500 to-violet-500 text-white shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-shadow disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Play className="w-5 h-5" />
                Démarrer l'événement
              </motion.button>
            )}

            {/* Info for participants */}
            {!isHost && (
              <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20">
                <p className="text-sm text-white/60 text-center">
                  Vous êtes prêt ! L'événement commencera quand l'hôte le décidera.
                </p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
