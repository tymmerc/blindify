import { motion } from 'motion/react';
import { Users, Play, Pause, Crown, User } from 'lucide-react';
import { useState } from 'react';

interface Participant {
  id: string;
  name: string;
  avatar: string;
  score: number;
  isHost?: boolean;
}

interface EventModeProps {
  isHost: boolean;
  participants: Participant[];
  isGameStarted: boolean;
  onStartGame?: () => void;
  onPauseGame?: () => void;
  onAnswer?: (answer: string) => void;
}

export function EventMode({
  isHost,
  participants,
  isGameStarted,
  onStartGame,
  onPauseGame,
  onAnswer,
}: EventModeProps) {
  const [answer, setAnswer] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim() && onAnswer) {
      onAnswer(answer);
      setAnswer('');
    }
  };

  const totalScore = participants.reduce((sum, p) => sum + p.score, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 pt-24 pb-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Event header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-3xl bg-gradient-to-r from-purple-300 to-violet-300 bg-clip-text text-transparent">
              Mode Événement
            </h2>
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-500/20 border border-purple-400/30">
              <Users className="w-5 h-5 text-purple-400" />
              <span className="text-white">{participants.length} participants</span>
            </div>
          </div>

          {/* Collective score */}
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="p-6 rounded-2xl bg-gradient-to-r from-purple-500/10 to-violet-500/10 border border-purple-400/30"
          >
            <div className="text-center">
              <p className="text-white/60 mb-2">Score Collectif</p>
              <motion.p
                key={totalScore}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="text-5xl text-white"
              >
                {totalScore}
              </motion.p>
            </div>
          </motion.div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Participants list (sidebar) */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h3 className="text-xl text-white mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-400" />
                Participants
              </h3>

              <div className="space-y-3">
                {participants.map((participant, index) => (
                  <motion.div
                    key={participant.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/10"
                  >
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-400 to-violet-600 flex items-center justify-center">
                        <span>{participant.avatar}</span>
                      </div>
                      {participant.isHost && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-yellow-500 rounded-full flex items-center justify-center border-2 border-gray-900">
                          <Crown className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{participant.name}</p>
                      <p className="text-white/50 text-xs">{participant.score} pts</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Main game area */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2"
          >
            {!isGameStarted ? (
              /* Waiting room */
              <div className="h-full flex flex-col items-center justify-center bg-white/5 border border-white/10 rounded-2xl p-12">
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500 to-violet-600 flex items-center justify-center mb-6"
                >
                  <Users className="w-12 h-12 text-white" />
                </motion.div>

                <h3 className="text-2xl text-white mb-4">
                  {isHost ? 'Prêt à commencer ?' : 'En attente de l\'hôte...'}
                </h3>

                <p className="text-white/60 mb-8 text-center max-w-md">
                  {isHost
                    ? 'Lancez la partie quand tous les participants sont prêts'
                    : 'L\'hôte va bientôt lancer la partie'}
                </p>

                {isHost && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onStartGame}
                    className="flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-purple-500 to-violet-600 text-white shadow-lg shadow-purple-500/30"
                  >
                    <Play className="w-5 h-5" />
                    Démarrer la partie
                  </motion.button>
                )}
              </div>
            ) : (
              /* Game in progress */
              <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
                {isHost ? (
                  /* Host controls */
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xl text-white">Contrôles Hôte</h3>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={onPauseGame}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-orange-500/20 border border-orange-400/30 text-orange-300"
                      >
                        <Pause className="w-4 h-4" />
                        Pause
                      </motion.button>
                    </div>

                    <div className="space-y-4">
                      <div className="p-6 rounded-xl bg-purple-500/10 border border-purple-400/30">
                        <p className="text-white/60 text-sm mb-2">Question en cours</p>
                        <p className="text-white text-lg">Track #5 - Genre: Pop</p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                          <p className="text-white/60 text-sm mb-1">Réponses reçues</p>
                          <p className="text-white text-2xl">8/{participants.length}</p>
                        </div>
                        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                          <p className="text-white/60 text-sm mb-1">Temps écoulé</p>
                          <p className="text-white text-2xl">00:12</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Participant view */
                  <div>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="mb-8 p-12 rounded-2xl bg-gradient-to-br from-purple-500/20 to-violet-500/20 border-2 border-purple-500/30"
                    >
                      <div className="flex items-center justify-center gap-2 h-32">
                        {[...Array(12)].map((_, i) => (
                          <motion.div
                            key={i}
                            animate={{
                              height: ['20%', '100%', '40%', '80%', '20%'],
                            }}
                            transition={{
                              duration: 1.5,
                              repeat: Infinity,
                              delay: i * 0.1,
                              ease: 'easeInOut',
                            }}
                            className="w-3 bg-gradient-to-t from-purple-500 to-violet-500 rounded-full"
                          />
                        ))}
                      </div>
                    </motion.div>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <input
                        type="text"
                        value={answer}
                        onChange={(e) => setAnswer(e.target.value)}
                        placeholder="Votre réponse..."
                        className="w-full px-6 py-4 bg-white/5 border-2 border-white/10 focus:border-purple-400/50 rounded-xl text-white placeholder-white/40 outline-none transition-colors"
                      />
                      <motion.button
                        type="submit"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        disabled={!answer.trim()}
                        className="w-full py-4 rounded-xl bg-gradient-to-r from-purple-500 to-violet-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Envoyer
                      </motion.button>
                    </form>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
