import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Music, Trophy, Zap, Clock, Send, Users, TrendingUp, MessageCircle } from 'lucide-react';

interface Message {
  id: string;
  user: string;
  message: string;
  timestamp: Date;
  isAnswer: boolean;
  isCorrect?: boolean;
}

interface ChatPlayer {
  name: string;
  score: number;
  streak: number;
}

interface ChatGameScreenProps {
  onSendMessage: (message: string) => void;
  questionNumber: number;
  totalQuestions: number;
  score: number;
  streak: number;
  messages: Message[];
}

export function ChatGameScreen({
  onSendMessage,
  questionNumber,
  totalQuestions,
  score,
  streak,
  messages,
}: ChatGameScreenProps) {
  const [timeLeft, setTimeLeft] = useState(20);
  const [message, setMessage] = useState('');
  const [showResult, setShowResult] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Mock data
  const question = {
    id: questionNumber,
    artist: 'Billie Eilish',
    title: 'bad guy',
    album: 'WHEN WE ALL FALL ASLEEP, WHERE DO WE GO?',
    year: 2019,
    audioWave: [0.4, 0.7, 0.5, 0.9, 0.6, 0.8, 0.4, 0.6, 0.9, 0.5, 0.7, 0.8, 0.4, 0.6, 0.5],
  };

  const topPlayers: ChatPlayer[] = [
    { name: 'MusicMaster42', score: 850, streak: 5 },
    { name: 'ProGamer123', score: 720, streak: 3 },
    { name: 'SongHunter', score: 680, streak: 2 },
    { name: 'ChatViewer99', score: 620, streak: 4 },
    { name: 'MelodyQueen', score: 590, streak: 1 },
  ];

  const viewerCount = 347;

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showResult) {
      setShowResult(true);
      setTimeout(() => {
        setShowResult(false);
        setTimeLeft(20);
      }, 3000);
    }
  }, [timeLeft, showResult]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message);
      setMessage('');
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Progress bar */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-white/60">
              Question {questionNumber} / {totalQuestions}
            </span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-sm text-white/60">{viewerCount} spectateurs</span>
              </div>
              <span className="text-sm text-cyan-400">
                {Math.round((questionNumber / totalQuestions) * 100)}%
              </span>
            </div>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
              transition={{ duration: 0.5 }}
            />
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main game area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Question card */}
            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-8 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 backdrop-blur-sm"
            >
              {/* Timer and streak */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center border-4 ${
                    timeLeft > 5 ? 'border-cyan-400' : 'border-red-400 animate-pulse'
                  } bg-black/50`}>
                    <span className={`text-2xl ${timeLeft > 5 ? 'text-cyan-400' : 'text-red-400'}`}>
                      {timeLeft}
                    </span>
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Temps restant</div>
                    <div className="text-white">20 secondes</div>
                  </div>
                </div>

                {streak > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/20 border border-cyan-500/30"
                  >
                    <Zap className="w-4 h-4 text-cyan-400" />
                    <span className="text-cyan-400">Série: {streak}</span>
                  </motion.div>
                )}
              </div>

              {/* Audio visualization */}
              <div className="mb-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center">
                    <Music className="w-6 h-6 text-cyan-400 animate-pulse" />
                  </div>
                  <div>
                    <div className="text-sm text-white/60">Morceau en cours</div>
                    <div className="text-white">Répondez dans le chat !</div>
                  </div>
                </div>

                {/* Waveform visualization */}
                <div className="flex items-end justify-center gap-1 h-32 bg-black/30 rounded-xl p-4">
                  {question.audioWave.map((height, i) => (
                    <motion.div
                      key={i}
                      initial={{ scaleY: 0 }}
                      animate={{ scaleY: 1 }}
                      transition={{ delay: i * 0.05, repeat: Infinity, repeatDelay: 1 }}
                      className="flex-1 bg-gradient-to-t from-cyan-500 to-blue-400 rounded-full"
                      style={{ height: `${height * 100}%` }}
                    />
                  ))}
                </div>
              </div>

              {/* Answer format hint */}
              <div className="p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                <div className="text-sm text-cyan-300 mb-1">Format de réponse</div>
                <div className="text-white/80 font-mono">!answer [Artiste - Titre]</div>
                <div className="text-xs text-white/40 mt-2">
                  Exemple: !answer Billie Eilish - bad guy
                </div>
              </div>
            </motion.div>

            {/* Chat interface */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm overflow-hidden"
            >
              <div className="p-4 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-lg">Chat en direct</h3>
                  <span className="ml-auto text-sm text-white/60">
                    {messages.length} messages
                  </span>
                </div>
              </div>

              {/* Messages */}
              <div className="h-96 overflow-y-auto p-4 space-y-3">
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-3 rounded-lg ${
                      msg.isAnswer
                        ? msg.isCorrect
                          ? 'bg-green-500/20 border border-green-500/30'
                          : 'bg-cyan-500/10 border border-cyan-500/20'
                        : 'bg-white/5'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      <div className="w-6 h-6 rounded bg-cyan-500/30 flex items-center justify-center text-xs">
                        {msg.user[0].toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm text-cyan-400">{msg.user}</span>
                          <span className="text-xs text-white/40">
                            {msg.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-white/90 text-sm">{msg.message}</div>
                      </div>
                    </div>
                  </motion.div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Message input */}
              <form onSubmit={handleSubmit} className="p-4 border-t border-white/10">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Tapez votre réponse..."
                    className="flex-1 px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white placeholder:text-white/40 focus:outline-none focus:border-cyan-500/50 transition-colors"
                  />
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    type="submit"
                    disabled={!message.trim()}
                    className="px-6 py-3 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-500 text-white disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
                  >
                    <Send className="w-5 h-5" />
                  </motion.button>
                </div>
              </form>
            </motion.div>
          </div>

          {/* Sidebar - Stats and leaderboard */}
          <div className="space-y-6">
            {/* Your score */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="p-6 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20"
            >
              <div className="flex items-center gap-3 mb-4">
                <Trophy className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Votre score</h3>
              </div>
              <div className="text-4xl text-cyan-400 mb-2">{score}</div>
              <div className="text-sm text-white/60">Points</div>
            </motion.div>

            {/* Viewer stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10"
            >
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Stream Stats</h3>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white/60">Spectateurs</span>
                  <span className="text-cyan-400">{viewerCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white/60">Joueurs actifs</span>
                  <span className="text-cyan-400">{topPlayers.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white/60">Messages</span>
                  <span className="text-cyan-400">{messages.length}</span>
                </div>
              </div>
            </motion.div>

            {/* Top players leaderboard */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10"
            >
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg">Top Joueurs</h3>
              </div>

              <div className="space-y-3">
                {topPlayers.map((player, index) => (
                  <motion.div
                    key={player.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`p-3 rounded-xl ${
                      index === 0
                        ? 'bg-cyan-500/20 border border-cyan-500/30'
                        : 'bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm ${
                          index === 0
                            ? 'bg-cyan-500/30 text-cyan-400'
                            : 'bg-white/10 text-white/60'
                        }`}
                      >
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="text-white text-sm">{player.name}</div>
                        {player.streak > 1 && (
                          <div className="flex items-center gap-1 text-xs text-white/40">
                            <Zap className="w-3 h-3" />
                            {player.streak}x
                          </div>
                        )}
                      </div>
                      <div className="text-cyan-400 text-sm">{player.score}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
