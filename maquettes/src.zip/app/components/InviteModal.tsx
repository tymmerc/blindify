import { motion, AnimatePresence } from 'motion/react';
import { X, Clock, User } from 'lucide-react';
import { useEffect, useState } from 'react';

interface InviteModalProps {
  isOpen: boolean;
  onAccept: () => void;
  onDecline: () => void;
  friendName: string;
  friendAvatar: string;
  expiresIn?: number; // seconds
}

export function InviteModal({
  isOpen,
  onAccept,
  onDecline,
  friendName,
  friendAvatar,
  expiresIn = 30,
}: InviteModalProps) {
  const [timeLeft, setTimeLeft] = useState(expiresIn);

  useEffect(() => {
    if (!isOpen) {
      setTimeLeft(expiresIn);
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          onDecline();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, expiresIn, onDecline]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onDecline}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md"
          >
            <div className="relative bg-gradient-to-br from-gray-900 to-black border-2 border-blue-500/30 rounded-2xl p-8 shadow-2xl shadow-blue-500/20">
              {/* Close button */}
              <motion.button
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onDecline}
                className="absolute top-4 right-4 p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5 text-white/60" />
              </motion.button>

              {/* Avatar */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', delay: 0.1 }}
                className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center text-3xl"
              >
                {friendAvatar}
              </motion.div>

              {/* Title */}
              <motion.h3
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-2xl text-center text-white mb-2"
              >
                Invitation reçue !
              </motion.h3>

              {/* Friend name */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="flex items-center justify-center gap-2 mb-6 text-white/70"
              >
                <User className="w-4 h-4" />
                <span>{friendName} vous invite à jouer</span>
              </motion.div>

              {/* Countdown */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 }}
                className="flex items-center justify-center gap-2 mb-8 p-4 rounded-xl bg-white/5 border border-white/10"
              >
                <Clock className="w-5 h-5 text-blue-400" />
                <span className="text-white/90">Expire dans</span>
                <motion.span
                  key={timeLeft}
                  initial={{ scale: 1.2, color: '#60a5fa' }}
                  animate={{ scale: 1, color: timeLeft <= 5 ? '#f87171' : '#60a5fa' }}
                  className="text-xl tabular-nums"
                >
                  {timeLeft}s
                </motion.span>
              </motion.div>

              {/* Progress bar */}
              <div className="mb-8 h-1 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: '100%' }}
                  animate={{ width: '0%' }}
                  transition={{ duration: expiresIn, ease: 'linear' }}
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-600"
                />
              </div>

              {/* Action buttons */}
              <div className="flex gap-4">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onDecline}
                  className="flex-1 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/70 transition-colors"
                >
                  Refuser
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onAccept}
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/30 transition-shadow hover:shadow-blue-500/50"
                >
                  Accepter
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
