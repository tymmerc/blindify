import { useState } from 'react';
import { motion } from 'motion/react';
import { Users, Crown, Settings, Play, Copy, Check, Music2, Clock, Trophy } from 'lucide-react';

interface Friend {
  id: string;
  name: string;
  avatar: string;
  status: 'online' | 'playing' | 'offline';
}

interface FriendsLobbyProps {
  onStartGame: () => void;
  friends: Friend[];
}

export function FriendsLobby({ onStartGame, friends }: FriendsLobbyProps) {
  const [selectedPlaylist, setSelectedPlaylist] = useState('top-hits');
  const [rounds, setRounds] = useState(10);
  const [difficulty, setDifficulty] = useState('medium');
  const [invitedFriends, setInvitedFriends] = useState<string[]>(['1', '2']);
  const [copied, setCopied] = useState(false);

  const lobbyCode = 'PARTY-2847';

  const playlists = [
    { id: 'top-hits', name: 'Top Hits 2024', count: 150 },
    { id: '90s', name: 'Années 90', count: 200 },
    { id: 'rock', name: 'Rock Classics', count: 180 },
    { id: 'hip-hop', name: 'Hip-Hop', count: 220 },
  ];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(lobbyCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleFriend = (friendId: string) => {
    setInvitedFriends((prev) =>
      prev.includes(friendId)
        ? prev.filter((id) => id !== friendId)
        : [...prev, friendId]
    );
  };

  return (
    <div className="min-h-screen pt-24 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/20 mb-4">
            <div className="w-2 h-2 rounded-full bg-pink-500" />
            <span className="text-xs uppercase tracking-wider text-pink-400">Mode Social</span>
          </div>
          <h1 className="text-5xl mb-3 bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">
            Salon privé
          </h1>
          <p className="text-white/60">
            Configurez votre partie et invitez vos amis
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Left column - Game settings */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6"
          >
            {/* Lobby code */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                    <Crown className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <h3 className="text-sm text-white/60">Code du salon</h3>
                    <p className="text-2xl tracking-wider text-pink-400">{lobbyCode}</p>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleCopyCode}
                  className="px-4 py-2 rounded-lg bg-pink-500/20 hover:bg-pink-500/30 border border-pink-500/30 transition-colors"
                >
                  {copied ? (
                    <Check className="w-5 h-5 text-pink-400" />
                  ) : (
                    <Copy className="w-5 h-5 text-pink-400" />
                  )}
                </motion.button>
              </div>
              <p className="text-sm text-white/40">
                Partagez ce code avec vos amis pour qu'ils rejoignent la partie
              </p>
            </div>

            {/* Playlist selection */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-4">
                <Music2 className="w-5 h-5 text-pink-400" />
                <h3 className="text-lg">Playlist</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {playlists.map((playlist) => (
                  <motion.button
                    key={playlist.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedPlaylist(playlist.id)}
                    className={`p-4 rounded-xl text-left transition-all ${
                      selectedPlaylist === playlist.id
                        ? 'bg-pink-500/20 border-2 border-pink-500/50'
                        : 'bg-white/5 border border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div className="text-white mb-1">{playlist.name}</div>
                    <div className="text-sm text-white/40">{playlist.count} morceaux</div>
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Game settings */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center gap-3 mb-6">
                <Settings className="w-5 h-5 text-pink-400" />
                <h3 className="text-lg">Paramètres de jeu</h3>
              </div>

              <div className="space-y-6">
                {/* Rounds */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-white/60" />
                      <span className="text-white/80">Nombre de rounds</span>
                    </div>
                    <span className="text-pink-400">{rounds}</span>
                  </div>
                  <div className="flex gap-2">
                    {[5, 10, 15, 20].map((value) => (
                      <motion.button
                        key={value}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setRounds(value)}
                        className={`flex-1 py-2 rounded-lg transition-all ${
                          rounds === value
                            ? 'bg-pink-500/30 border border-pink-500/50'
                            : 'bg-white/5 border border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {value}
                      </motion.button>
                    ))}
                  </div>
                </div>

                {/* Difficulty */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Trophy className="w-4 h-4 text-white/60" />
                    <span className="text-white/80">Difficulté</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['easy', 'medium', 'hard'].map((level) => (
                      <motion.button
                        key={level}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setDifficulty(level)}
                        className={`py-2 rounded-lg capitalize transition-all ${
                          difficulty === level
                            ? 'bg-pink-500/30 border border-pink-500/50'
                            : 'bg-white/5 border border-white/10 hover:bg-white/10'
                        }`}
                      >
                        {level === 'easy' && 'Facile'}
                        {level === 'medium' && 'Moyen'}
                        {level === 'hard' && 'Difficile'}
                      </motion.button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right column - Players */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            {/* Players list */}
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-pink-400" />
                  <h3 className="text-lg">Joueurs</h3>
                </div>
                <span className="text-sm text-white/60">{invitedFriends.length + 1}/8</span>
              </div>

              <div className="space-y-2 mb-6">
                {/* Host (you) */}
                <div className="p-3 rounded-xl bg-pink-500/10 border border-pink-500/20">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-pink-500/30 flex items-center justify-center">
                      🎮
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-white">Vous</span>
                        <Crown className="w-3 h-3 text-pink-400" />
                      </div>
                      <span className="text-xs text-white/60">Hôte</span>
                    </div>
                    <div className="w-2 h-2 rounded-full bg-pink-500" />
                  </div>
                </div>

                {/* Invited friends */}
                {friends
                  .filter((f) => invitedFriends.includes(f.id))
                  .map((friend) => (
                    <div
                      key={friend.id}
                      className="p-3 rounded-xl bg-white/5 border border-white/10"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                          {friend.avatar}
                        </div>
                        <div className="flex-1">
                          <div className="text-white">{friend.name}</div>
                          <span className="text-xs text-white/60">
                            {friend.status === 'online' && 'En ligne'}
                            {friend.status === 'playing' && 'En jeu'}
                            {friend.status === 'offline' && 'Hors ligne'}
                          </span>
                        </div>
                        <div
                          className={`w-2 h-2 rounded-full ${
                            friend.status === 'online'
                              ? 'bg-green-500'
                              : friend.status === 'playing'
                              ? 'bg-yellow-500'
                              : 'bg-white/20'
                          }`}
                        />
                      </div>
                    </div>
                  ))}
              </div>

              {/* Invite friends */}
              <div>
                <div className="text-sm text-white/60 mb-2">Inviter des amis</div>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {friends
                    .filter((f) => !invitedFriends.includes(f.id))
                    .map((friend) => (
                      <motion.button
                        key={friend.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => toggleFriend(friend.id)}
                        className="w-full p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-sm">
                            {friend.avatar}
                          </div>
                          <div className="flex-1 text-left">
                            <div className="text-sm text-white">{friend.name}</div>
                          </div>
                          <div
                            className={`w-2 h-2 rounded-full ${
                              friend.status === 'online' ? 'bg-green-500' : 'bg-white/20'
                            }`}
                          />
                        </div>
                      </motion.button>
                    ))}
                </div>
              </div>
            </div>

            {/* Start button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onStartGame}
              disabled={invitedFriends.length === 0}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-pink-500 to-rose-500 text-white shadow-lg shadow-pink-500/30 hover:shadow-pink-500/50 transition-shadow disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Play className="w-5 h-5" />
              Lancer la partie
            </motion.button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
