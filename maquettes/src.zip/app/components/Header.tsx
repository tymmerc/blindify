import { ArrowLeft, Settings, Volume2 } from 'lucide-react';
import { motion } from 'motion/react';

interface HeaderProps {
  onBack?: () => void;
  showBack?: boolean;
  currentTrack?: string;
}

export function Header({ onBack, showBack, currentTrack }: HeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left section */}
          <div className="flex items-center gap-4">
            {showBack && (
              <motion.button
                whileHover={{ scale: 1.05, x: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={onBack}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-white" />
              </motion.button>
            )}
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent"
            >
              BLINDIFY
            </motion.div>
          </div>

          {/* Center section - Current track */}
          {currentTrack && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="hidden md:flex items-center gap-2 px-4 py-2 rounded-full bg-white/5"
            >
              <Volume2 className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-white/70">{currentTrack}</span>
            </motion.div>
          )}

          {/* Right section */}
          <motion.button
            whileHover={{ scale: 1.05, rotate: 90 }}
            whileTap={{ scale: 0.95 }}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
          >
            <Settings className="w-5 h-5 text-white" />
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
}
