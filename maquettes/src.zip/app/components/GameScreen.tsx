import { motion } from 'motion/react';
import { Music, Zap, Trophy } from 'lucide-react';
import { useState, useEffect } from 'react';

interface GameScreenProps {
  mode: 'friends' | 'event' | 'chat';
  onAnswer: (answer: string) => void;
  questionNumber: number;
  totalQuestions: number;
  score: number;
  streak: number;
  timeLimit?: number; // seconds
}

export function GameScreen({
  mode,
  onAnswer,
  questionNumber,
  totalQuestions,
  score,
  streak,
  timeLimit = 15,
}: GameScreenProps) {
  const [answer, setAnswer] = useState('');
  const [timeLeft, setTimeLeft] = useState(timeLimit);

  const modeColors = {
    friends: { primary: 'blue', accent: 'from-blue-500 to-cyan-500' },
    event: { primary: 'purple', accent: 'from-purple-500 to-violet-500' },
    chat: { primary: 'pink', accent: 'from-pink-500 to-rose-500' },
  };

  const colors = modeColors[mode];

  useEffect(() => {
    setTimeLeft(timeLimit);
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [questionNumber, timeLimit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim()) {
      onAnswer(answer);
      setAnswer('');
    }
  };

  const progress = (questionNumber / totalQuestions) * 100;
  const timeProgress = (timeLeft / timeLimit) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 pt-24 pb-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header stats */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-6">
            {/* Score */}
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span className="text-white/70 text-sm">Score:</span>
              <span className="text-white text-lg">{score}</span>
            </div>

            {/* Streak */}
            {streak > 0 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-orange-500/20 border border-orange-400/30"
              >
                <Zap className="w-5 h-5 text-orange-400" />
                <span className="text-orange-300">{streak}x</span>
              </motion.div>
            )}
          </div>

          {/* Question counter */}
          <div className="text-white/70">
            Question <span className="text-white">{questionNumber}</span> / {totalQuestions}
          </div>
        </motion.div>

        {/* Progress bar */}
        <div className="mb-8 h-2 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            className={`h-full bg-gradient-to-r ${colors.accent}`}
          />
        </div>

        {/* Audio visualization */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`mb-8 p-12 rounded-3xl bg-gradient-to-br ${colors.accent} bg-opacity-10 border-2 border-${colors.primary}-500/30 relative overflow-hidden`}
        >
          {/* Animated audio bars */}
          <div className="flex items-center justify-center gap-2 h-32">
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  height: ['20%', '100%', '40%', '80%', '20%'],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.1,
                  ease: 'easeInOut',
                }}
                className={`w-3 bg-gradient-to-t ${colors.accent} rounded-full`}
              />
            ))}
          </div>

          {/* Music icon */}
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute top-6 left-6"
          >
            <Music className={`w-8 h-8 text-${colors.primary}-400`} />
          </motion.div>

          {/* Timer circle */}
          <motion.div
            className="absolute top-6 right-6 w-16 h-16 rounded-full bg-black/30 flex items-center justify-center"
          >
            <svg className="w-full h-full -rotate-90">
              <circle
                cx="32"
                cy="32"
                r="28"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                className="text-white/10"
              />
              <motion.circle
                cx="32"
                cy="32"
                r="28"
                stroke="currentColor"
                strokeWidth="4"
                fill="none"
                className={`text-${colors.primary}-400`}
                strokeDasharray={175.93}
                animate={{ strokeDashoffset: 175.93 * (1 - timeProgress / 100) }}
                transition={{ duration: 1, ease: 'linear' }}
              />
            </svg>
            <motion.span
              key={timeLeft}
              initial={{ scale: 1.2 }}
              animate={{ scale: 1 }}
              className={`absolute text-xl ${timeLeft <= 5 ? 'text-red-400' : 'text-white'}`}
            >
              {timeLeft}
            </motion.span>
          </motion.div>
        </motion.div>

        {/* Answer input */}
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="space-y-4"
        >
          <div className="relative">
            <input
              type="text"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              placeholder="Entrez le titre ou l'artiste..."
              className="w-full px-6 py-4 bg-white/5 border-2 border-white/10 focus:border-white/30 rounded-xl text-white placeholder-white/40 outline-none transition-colors"
              autoFocus
            />
          </div>

          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            disabled={!answer.trim()}
            className={`w-full py-4 rounded-xl bg-gradient-to-r ${colors.accent} text-white disabled:opacity-50 disabled:cursor-not-allowed shadow-lg transition-shadow hover:shadow-2xl`}
          >
            Valider la réponse
          </motion.button>
        </motion.form>

        {/* Hint */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-white/40 text-sm mt-4"
        >
          Appuyez sur Entrée pour soumettre votre réponse
        </motion.p>
      </div>
    </div>
  );
}
