import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';

interface ModeCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  accentColor: 'blue' | 'purple' | 'pink';
  onClick: () => void;
  badge?: string;
}

const colorClasses = {
  blue: {
    gradient: 'from-blue-500/20 to-cyan-500/20',
    border: 'border-blue-500/30 hover:border-blue-400/60',
    glow: 'hover:shadow-blue-500/20',
    icon: 'text-blue-400',
    title: 'from-blue-300 to-cyan-300',
    badge: 'bg-cyan-500/20 border-cyan-500/30 text-cyan-400',
    dot: 'bg-cyan-500',
  },
  purple: {
    gradient: 'from-purple-500/20 to-violet-500/20',
    border: 'border-purple-500/30 hover:border-purple-400/60',
    glow: 'hover:shadow-purple-500/20',
    icon: 'text-purple-400',
    title: 'from-purple-300 to-violet-300',
    badge: 'bg-purple-500/20 border-purple-500/30 text-purple-400',
    dot: 'bg-purple-500',
  },
  pink: {
    gradient: 'from-pink-500/20 to-rose-500/20',
    border: 'border-pink-500/30 hover:border-pink-400/60',
    glow: 'hover:shadow-pink-500/20',
    icon: 'text-pink-400',
    title: 'from-pink-300 to-rose-300',
    badge: 'bg-pink-500/20 border-pink-500/30 text-pink-400',
    dot: 'bg-pink-500',
  },
};

export function ModeCard({ icon: Icon, title, description, accentColor, onClick, badge }: ModeCardProps) {
  const colors = colorClasses[accentColor];

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -4 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className={`
        relative group cursor-pointer
        bg-gradient-to-br ${colors.gradient}
        border-2 ${colors.border}
        rounded-2xl p-8
        transition-all duration-300
        hover:shadow-2xl ${colors.glow}
        backdrop-blur-sm
      `}
    >
      {/* Glow effect on hover */}
      <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${colors.gradient} opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-300 -z-10`} />

      {/* Badge */}
      {badge && (
        <div className="flex items-center justify-between mb-6">
          <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border ${colors.badge}`}>
            <div className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
            <span className="text-xs uppercase tracking-wider">Mode</span>
          </div>
        </div>
      )}

      {/* Icon */}
      <motion.div
        whileHover={{ rotate: 5, scale: 1.1 }}
        transition={{ type: 'spring', stiffness: 300 }}
        className={`w-16 h-16 mx-auto mb-6 ${colors.icon}`}
      >
        <Icon className="w-full h-full" strokeWidth={1.5} />
      </motion.div>

      {/* Title */}
      <h3 className={`text-2xl font-bold mb-3 text-center bg-gradient-to-r ${colors.title} bg-clip-text text-transparent`}>
        {title}
      </h3>

      {/* Description */}
      <p className="text-white/60 text-center leading-relaxed">
        {description}
      </p>

      {/* Badge at bottom */}
      {badge && (
        <div className="mt-6 flex justify-center">
          <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full ${colors.badge}`}>
            <span className="text-xs uppercase tracking-wider">Posture</span>
            <span className="text-xs">{badge}</span>
          </div>
        </div>
      )}

      {/* Hover indicator */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        whileHover={{ opacity: 1, y: 0 }}
        className={`${badge ? 'mt-4' : 'mt-6'} text-center text-sm text-white/40`}
      >
        Cliquer pour commencer →
      </motion.div>
    </motion.div>
  );
}