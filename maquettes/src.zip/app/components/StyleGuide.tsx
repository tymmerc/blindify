import { motion } from 'motion/react';
import { Palette, Type, Layout, Zap } from 'lucide-react';

export function StyleGuide() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 pt-24 pb-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-5xl bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
            Guide de Style Blindify
          </h1>
          <p className="text-white/60 text-lg">Direction artistique et composants réutilisables</p>
        </motion.div>

        {/* Colors */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Palette className="w-6 h-6 text-purple-400" />
            <h2 className="text-3xl text-white">Palette de Couleurs</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Friends mode - Blue */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h3 className="text-xl text-blue-400 mb-4">Mode Amis - Bleu</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-blue-400" />
                  <div>
                    <p className="text-white text-sm">Primary</p>
                    <p className="text-white/60 text-xs">#60a5fa</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-cyan-400" />
                  <div>
                    <p className="text-white text-sm">Accent</p>
                    <p className="text-white/60 text-xs">#22d3ee</p>
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-gradient-to-r from-blue-500 to-cyan-500">
                  <p className="text-white text-sm">Gradient</p>
                </div>
              </div>
            </div>

            {/* Event mode - Purple */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h3 className="text-xl text-purple-400 mb-4">Mode Événement - Violet</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-purple-400" />
                  <div>
                    <p className="text-white text-sm">Primary</p>
                    <p className="text-white/60 text-xs">#c084fc</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-violet-400" />
                  <div>
                    <p className="text-white text-sm">Accent</p>
                    <p className="text-white/60 text-xs">#a78bfa</p>
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-gradient-to-r from-purple-500 to-violet-500">
                  <p className="text-white text-sm">Gradient</p>
                </div>
              </div>
            </div>

            {/* Chat mode - Pink */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
              <h3 className="text-xl text-pink-400 mb-4">Mode Chat - Rose</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-pink-400" />
                  <div>
                    <p className="text-white text-sm">Primary</p>
                    <p className="text-white/60 text-xs">#f472b6</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg bg-rose-400" />
                  <div>
                    <p className="text-white text-sm">Accent</p>
                    <p className="text-white/60 text-xs">#fb7185</p>
                  </div>
                </div>
                <div className="p-4 rounded-lg bg-gradient-to-r from-pink-500 to-rose-500">
                  <p className="text-white text-sm">Gradient</p>
                </div>
              </div>
            </div>
          </div>

          {/* Base colors */}
          <div className="mt-6 bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-xl text-white mb-4">Couleurs de Base</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="w-full h-20 rounded-lg bg-black mb-2" />
                <p className="text-white text-sm">Background</p>
                <p className="text-white/60 text-xs">#000000</p>
              </div>
              <div>
                <div className="w-full h-20 rounded-lg bg-gray-900 mb-2" />
                <p className="text-white text-sm">Dark Gray</p>
                <p className="text-white/60 text-xs">#111827</p>
              </div>
              <div>
                <div className="w-full h-20 rounded-lg bg-white/10 mb-2 border border-white/20" />
                <p className="text-white text-sm">Card BG</p>
                <p className="text-white/60 text-xs">white/10</p>
              </div>
              <div>
                <div className="w-full h-20 rounded-lg bg-white mb-2" />
                <p className="text-white text-sm">Text</p>
                <p className="text-white/60 text-xs">#ffffff</p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Typography */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Type className="w-6 h-6 text-purple-400" />
            <h2 className="text-3xl text-white">Typographie</h2>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-8 space-y-6">
            <div>
              <p className="text-5xl text-white mb-2">Titre Principal</p>
              <p className="text-white/60 text-sm">text-5xl • 48px</p>
            </div>
            <div>
              <p className="text-3xl text-white mb-2">Sous-titre</p>
              <p className="text-white/60 text-sm">text-3xl • 30px</p>
            </div>
            <div>
              <p className="text-xl text-white mb-2">Titre de section</p>
              <p className="text-white/60 text-sm">text-xl • 20px</p>
            </div>
            <div>
              <p className="text-base text-white mb-2">Corps de texte</p>
              <p className="text-white/60 text-sm">text-base • 16px</p>
            </div>
            <div>
              <p className="text-sm text-white/70 mb-2">Texte secondaire</p>
              <p className="text-white/60 text-sm">text-sm • 14px • opacity 70%</p>
            </div>
            <div>
              <p className="text-xs text-white/60 mb-2">Texte tertiaire</p>
              <p className="text-white/60 text-sm">text-xs • 12px • opacity 60%</p>
            </div>
          </div>
        </motion.section>

        {/* Components */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Layout className="w-6 h-6 text-purple-400" />
            <h2 className="text-3xl text-white">Composants</h2>
          </div>

          <div className="space-y-6">
            {/* Buttons */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
              <h3 className="text-xl text-white mb-6">Boutons</h3>
              <div className="flex flex-wrap gap-4">
                <button className="px-6 py-3 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
                  Primary Button
                </button>
                <button className="px-6 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white">
                  Secondary Button
                </button>
                <button className="px-6 py-3 rounded-xl bg-white/5 text-white/50 cursor-not-allowed">
                  Disabled Button
                </button>
              </div>
            </div>

            {/* Cards */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
              <h3 className="text-xl text-white mb-6">Cartes</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-6 rounded-xl bg-white/5 border border-white/10">
                  <h4 className="text-white mb-2">Carte simple</h4>
                  <p className="text-white/60 text-sm">Fond semi-transparent avec bordure subtile</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border-2 border-blue-500/30">
                  <h4 className="text-white mb-2">Carte avec accent</h4>
                  <p className="text-white/60 text-sm">Gradient de fond avec bordure colorée</p>
                </div>
              </div>
            </div>

            {/* Inputs */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
              <h3 className="text-xl text-white mb-6">Champs de saisie</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Champ de texte normal"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/40 outline-none"
                />
                <input
                  type="text"
                  placeholder="Champ de texte focus"
                  className="w-full px-4 py-3 bg-white/5 border-2 border-blue-400/50 rounded-xl text-white placeholder-white/40 outline-none"
                />
              </div>
            </div>
          </div>
        </motion.section>

        {/* Micro-interactions */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-6">
            <Zap className="w-6 h-6 text-purple-400" />
            <h2 className="text-3xl text-white">Micro-interactions</h2>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-2xl p-8">
            <div className="space-y-8">
              <div>
                <h3 className="text-white mb-4">Hover Scale</h3>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="inline-block px-6 py-3 rounded-xl bg-gradient-to-r from-purple-500 to-violet-500 text-white cursor-pointer"
                >
                  Survolez-moi
                </motion.div>
              </div>

              <div>
                <h3 className="text-white mb-4">Pulse Animation</h3>
                <div className="flex items-center gap-3">
                  <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse" />
                  <span className="text-white/70">Statut en ligne</span>
                </div>
              </div>

              <div>
                <h3 className="text-white mb-4">Loading Bars</h3>
                <div className="flex items-center gap-2 h-16">
                  {[...Array(8)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{
                        height: ['20%', '100%', '40%', '80%', '20%'],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        delay: i * 0.1,
                        ease: 'easeInOut',
                      }}
                      className="w-2 bg-gradient-to-t from-blue-500 to-purple-500 rounded-full"
                    />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-white mb-4">Glow Effect</h3>
                <motion.div
                  whileHover={{ boxShadow: '0 0 40px rgba(139, 92, 246, 0.6)' }}
                  className="inline-block px-6 py-3 rounded-xl bg-purple-500/20 border border-purple-400/30 text-purple-300 cursor-pointer transition-shadow"
                >
                  Survolez pour le glow
                </motion.div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Notes */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="bg-blue-500/10 border border-blue-400/30 rounded-2xl p-8">
            <h3 className="text-xl text-blue-300 mb-4">Notes de Design</h3>
            <ul className="space-y-3 text-white/70">
              <li>• Utiliser des bordures semi-transparentes (white/10) pour les séparateurs</li>
              <li>• Les cartes ont un fond white/5 avec backdrop-blur pour l'effet glassmorphism</li>
              <li>• Les gradients sont utilisés pour les accents et les CTAs principaux</li>
              <li>• Les animations sont subtiles (scale 1.05) pour ne pas être intrusives</li>
              <li>• Les états hover/active sont indiqués par des changements d'opacité et de scale</li>
              <li>• Les transitions durent généralement 200-300ms pour rester réactives</li>
              <li>• Chaque mode a sa propre couleur d'accent pour la reconnaissance visuelle</li>
            </ul>
          </div>
        </motion.section>
      </div>
    </div>
  );
}
