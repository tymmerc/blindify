import { motion } from 'motion/react';
import { Trophy, Star, TrendingUp, RotateCw, Home } from 'lucide-react';

interface ResultsScreenProps {
  mode: 'friends' | 'event' | 'chat';
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  bestStreak: number;
  onPlayAgain: () => void;
  onBackToHome: () => void;
}

export function ResultsScreen({
  mode,
  score,
  totalQuestions,
  correctAnswers,
  bestStreak,
  onPlayAgain,
  onBackToHome,
}: ResultsScreenProps) {
  const modeColors = {
    friends: { accent: 'from-blue-500 to-cyan-500', color: 'blue' },
    event: { accent: 'from-purple-500 to-violet-500', color: 'purple' },
    chat: { accent: 'from-pink-500 to-rose-500', color: 'pink' },
  };

  const colors = modeColors[mode];
  const accuracy = Math.round((correctAnswers / totalQuestions) * 100);

  const getPerformanceMessage = () => {
    if (accuracy >= 90) return '🎉 Performance exceptionnelle !';
    if (accuracy >= 70) return '🔥 Très bonne partie !';
    if (accuracy >= 50) return '👍 Bon travail !';
    return '💪 Continuez à vous entraîner !';
  };

  const getPerformanceColor = () => {
    if (accuracy >= 90) return 'text-yellow-400';
    if (accuracy >= 70) return 'text-green-400';
    if (accuracy >= 50) return 'text-blue-400';
    return 'text-purple-400';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 pt-24 pb-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Trophy animation */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', duration: 1 }}
          className="text-center mb-8"
        >
          <div className={`inline-flex w-24 h-24 rounded-full bg-gradient-to-br ${colors.accent} items-center justify-center mb-4 shadow-2xl`}>
            <Trophy className="w-12 h-12 text-white" />
          </div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className={`text-4xl mb-2 ${getPerformanceColor()}`}
          >
            {getPerformanceMessage()}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-white/60"
          >
            Voici vos résultats
          </motion.p>
        </motion.div>

        {/* Main score card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className={`mb-8 p-8 rounded-3xl bg-gradient-to-br ${colors.accent} bg-opacity-10 border-2 border-${colors.color}-500/30 relative overflow-hidden`}
        >
          {/* Background glow */}
          <div className={`absolute inset-0 bg-gradient-to-br ${colors.accent} opacity-5 blur-3xl`} />

          <div className="relative text-center">
            <p className="text-white/60 mb-2">Score Final</p>
            <motion.p
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', delay: 0.8 }}
              className="text-7xl text-white mb-4"
            >
              {score}
            </motion.p>
            <div className="flex items-center justify-center gap-2">
              {[...Array(5)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: i < Math.ceil((accuracy / 100) * 5) ? 1 : 0.2, scale: 1 }}
                  transition={{ delay: 1 + i * 0.1 }}
                >
                  <Star className={`w-6 h-6 ${i < Math.ceil((accuracy / 100) * 5) ? 'text-yellow-400 fill-yellow-400' : 'text-white/20'}`} />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Stats grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="grid grid-cols-3 gap-4 mb-8"
        >
          {/* Correct answers */}
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
            <div className="text-3xl text-white mb-2">{correctAnswers}</div>
            <div className="text-sm text-white/60">Bonnes réponses</div>
            <div className="text-xs text-white/40 mt-1">sur {totalQuestions}</div>
          </div>

          {/* Accuracy */}
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
            <div className={`text-3xl mb-2 ${getPerformanceColor()}`}>{accuracy}%</div>
            <div className="text-sm text-white/60">Précision</div>
            <div className="text-xs text-white/40 mt-1">
              {accuracy >= 70 ? 'Excellent' : accuracy >= 50 ? 'Bien' : 'À améliorer'}
            </div>
          </div>

          {/* Best streak */}
          <div className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center">
            <div className="flex items-center justify-center gap-1 mb-2">
              <TrendingUp className="w-6 h-6 text-orange-400" />
              <span className="text-3xl text-white">{bestStreak}</span>
            </div>
            <div className="text-sm text-white/60">Meilleure série</div>
            <div className="text-xs text-white/40 mt-1">réponses consécutives</div>
          </div>
        </motion.div>

        {/* Progress bar */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ delay: 1.4 }}
          className="mb-8"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-white/60">Progression</span>
            <span className="text-sm text-white">{correctAnswers}/{totalQuestions}</span>
          </div>
          <div className="h-3 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${accuracy}%` }}
              transition={{ delay: 1.6, duration: 1 }}
              className={`h-full bg-gradient-to-r ${colors.accent} rounded-full relative`}
            >
              <div className="absolute inset-0 bg-white/20 animate-pulse" />
            </motion.div>
          </div>
        </motion.div>

        {/* Action buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.8 }}
          className="flex gap-4"
        >
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onBackToHome}
            className="flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-colors"
          >
            <Home className="w-5 h-5" />
            Retour à l'accueil
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={onPlayAgain}
            className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-xl bg-gradient-to-r ${colors.accent} text-white shadow-lg hover:shadow-2xl transition-shadow`}
          >
            <RotateCw className="w-5 h-5" />
            Rejouer
          </motion.button>
        </motion.div>

        {/* Share prompt */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="mt-8 text-center text-white/40 text-sm"
        >
          Partagez votre score avec vos amis ! 🎵
        </motion.div>
      </div>
    </div>
  );
}
